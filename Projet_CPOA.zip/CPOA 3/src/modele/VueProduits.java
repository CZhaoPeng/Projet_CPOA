package modele;

import java.io.IOException;
import java.net.URL;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class VueProduits extends Stage{
	public VueProduits() throws IOException{
		try{
			final URL fxmlURL= getClass().getResource("/application/produits.fxml");
			final FXMLLoader fxmlLoader=new FXMLLoader(fxmlURL);
			final VBox node = (VBox)fxmlLoader.load();
			Scene scene = new Scene(node);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			//CtrlProduit controleur = fxmlLoader.getController();
//			controleur.setVue();
			String erreur1 ="le libelle n'est pas correct";
			String erreur2 ="le tarif n'est pas correct";
			String erreur3 ="le titre ne doit pas etre vide ";
			Alert alert = new Alert(Alert.AlertType.ERROR);
			//alert.initOwner(primaryStage);
			alert.setTitle("Erreur lors de la saisie");
			alert.setHeaderText("Un ou plusieurs champs sont mal remplis.");
			alert.setContentText(erreur1);
			alert.setContentText(erreur2);
			alert.setContentText(erreur3);
			alert.showAndWait();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
