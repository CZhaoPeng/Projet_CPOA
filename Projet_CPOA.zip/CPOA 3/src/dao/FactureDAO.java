package dao;

import metier.Facture;

public interface FactureDAO extends DAO<Facture>{

}
