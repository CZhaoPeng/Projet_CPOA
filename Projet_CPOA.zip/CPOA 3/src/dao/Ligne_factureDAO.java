package dao;

import metier.Ligne_facture;

public interface Ligne_factureDAO extends DAO<Ligne_facture>{

}
