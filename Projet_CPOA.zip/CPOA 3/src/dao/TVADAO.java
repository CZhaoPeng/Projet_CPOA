package dao;

import metier.TVA;

public interface TVADAO extends DAO<TVA>{

}
