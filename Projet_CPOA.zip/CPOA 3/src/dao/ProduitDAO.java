package dao;

import metier.Produit;

public interface ProduitDAO extends DAO<Produit>{

}
