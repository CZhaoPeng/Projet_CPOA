package dao;

import metier.Client;

public interface ClientDAO extends DAO<Client>{

}
