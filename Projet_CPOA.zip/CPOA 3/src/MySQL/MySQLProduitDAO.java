package MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import dao.ProduitDAO;
import metier.Connexion;
import metier.Produit;

public class MySQLProduitDAO implements ProduitDAO{
	private static MySQLProduitDAO instance;
	public MySQLProduitDAO(){
		
	}
	public static MySQLProduitDAO getInstance(){
		if(instance == null)
		{
			instance = new MySQLProduitDAO();
		}
		return instance;
	}
	@Override
	public Produit getById(int id) {
	
		try(
				PreparedStatement requete = Connexion.getInstance().creeConnexion().prepareStatement("select * from produit where id_produit=?");
				) 
		{
			
			requete.setInt(1, id);
			ResultSet res = requete.executeQuery();
				
				
				if(res.next()) {
					Produit p =new Produit();
					p.setId(res.getInt(1));
					p.setLibelle(res.getString("libelle_produit"));
					p.setPrix(res.getFloat("prix_produit"));
					p.setIdtva(MySQLTVADAO.getInstance().getById(res.getInt("id_tva")));
					return p;
				}
			}
			catch(SQLException sqle) {
				System.out.println("Pb select"+sqle.getMessage());
			}
			
			return null;
	}

	@Override
	public void create(Produit objet) {
		
		try(
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("insert produit (libelle_produit,prix_produit,id_tva) values(?,?,?)",Statement.RETURN_GENERATED_KEYS);
				)
		{ 
			requete.setString(1, objet.getLibelle());
			requete.setFloat(2, objet.getPrix());
			requete.setInt(3, objet.getIdtva().getId());
			 requete.executeUpdate();
		
			 ResultSet res = requete.getGeneratedKeys();
				if (res.next())
					objet.setId(res.getInt(1));
		}
		catch(SQLException sqle) {
			System.out.println("Pb create"+sqle.getMessage());
		}
		
	}

	@Override
	public void update(Produit objet) {
		try (
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("update produit set libelle_produit=?,prix_produit=?, id_tva =? where id_produit=?");
				)
		{
			
			
			requete.setString(1, objet.getLibelle());
			requete.setFloat(2, objet.getPrix());
			requete.setInt(3, objet.getIdtva().getId());
			requete.setInt(4, objet.getId());
			requete.executeUpdate();

		}
		catch(SQLException sqle) {
			System.out.println("Pb update"+sqle.getMessage());
		}
	}

	@Override
	public void delete(Produit objet) {
		try(
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("delete from produit where id_produit = ?");
				) 
		{
			
			requete.setInt(1,objet.getId());
			requete.executeUpdate();
				
		}
		catch(SQLException sqle) {
			System.out.println("Pb delete"+sqle.getMessage());
		}
		
	}
	
	@Override
	public ArrayList<Produit> findAll() {
		ArrayList<Produit> listeproduit = new ArrayList<Produit>();
		try(
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				 Statement requete = laConnexion.createStatement();
				ResultSet res = requete.executeQuery("SELECT * FROM produit");	
			)
		{
			while(res.next()){

				listeproduit.add(new Produit(res.getInt(1),res.getString("libelle_produit"),res.getFloat("prix_produit"),
						MySQLTVADAO.getInstance().getById(res.getInt("id_tva"))));
			}
		}catch(SQLException sqle) {
			System.out.println("Pb produitfindAll "+sqle.getMessage());
		}
		return listeproduit;
	}
}
