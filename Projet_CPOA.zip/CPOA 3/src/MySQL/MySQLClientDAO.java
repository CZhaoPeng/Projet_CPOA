package MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import dao.ClientDAO;
import metier.Client;
import metier.Connexion;

public class MySQLClientDAO implements ClientDAO{
	private static MySQLClientDAO instance;
	
	public MySQLClientDAO(){
		
	}
	public static MySQLClientDAO getInstance(){
		if(instance == null)
		{
			instance = new MySQLClientDAO();
		}
		return instance;
	}
	@Override
	public Client getById(int id) {
		try
		(
				PreparedStatement requete = Connexion.getInstance().creeConnexion().prepareStatement("SELECT * FROM client WHERE id_client =?");		
		)
		{
			requete.setInt(1, id);
			ResultSet res = requete.executeQuery();
				
			if (res.next()){
				Client c = new Client();
				c.setId(res.getInt(1));
				c.setNom(res.getString("nom"));
				c.setPrenom(res.getString("prenom"));
				return c;
			}
		}
		catch(SQLException sqle) {
			System.out.println("Pb select ID "+sqle.getMessage());
			
		}
		return null;
	}

	@Override
	public void create(Client objet) {
		
		try(
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("insert client (nom,prenom) values(?,?)",Statement.RETURN_GENERATED_KEYS);
		){ 
			requete.setString(1, objet.getNom());
			requete.setString(2, objet.getPrenom());
			requete.executeUpdate();
			
			ResultSet res = requete.getGeneratedKeys();
			if (res.next())
				objet.setId(res.getInt(1));
		}
		catch(SQLException sqle) {
			System.out.println("Pb create "+sqle.getMessage());
		}
		
	}

	@Override
	public void update(Client objet) {
		try (
			Connection laConnexion = Connexion.getInstance().creeConnexion();
			PreparedStatement requete = laConnexion.prepareStatement("update client set nom=?,prenom=? where id_client=?");
		){
			requete.setInt(3, objet.getId());
			requete.setString(1, objet.getNom());
			requete.setString(2, objet.getPrenom());
			requete.executeUpdate();
		}
		catch(SQLException sqle) {
			System.out.println("Pb update "+sqle.getMessage());
		}
	}

	@Override
	public void delete(Client objet) {
		try	(
			Connection laConnexion = Connexion.getInstance().creeConnexion();
			PreparedStatement requete = laConnexion.prepareStatement("delete from client where id_client = ?");
		){
			requete.setInt(1,objet.getId());
			requete.executeUpdate();
		}
		catch(SQLException sqle) {
			System.out.println("Pb delete "+sqle.getMessage());
		}
		
	}
	@Override
	public ArrayList<Client> findAll() {
		
		ArrayList<Client> listeclient = new ArrayList<>();
		try (
			Connection laConnexion = Connexion.getInstance().creeConnexion();
			PreparedStatement requete = laConnexion.prepareStatement("select * from client");
			ResultSet res = requete.executeQuery();
		){
			while(res.next())
				listeclient.add(new Client(res.getInt(1), res.getString(2), res.getString(3)));
		}
		catch(SQLException sqle) {
			System.out.println("Pba clientfindAll "+sqle.getMessage());
		}
		
		return listeclient;
	}
}
