package MySQL;

import dao.ClientDAO;
import dao.DAOFactory;
import dao.FactureDAO;
import dao.Ligne_factureDAO;
import dao.ProduitDAO;
import dao.TVADAO;

public class MySQLDAOFactory extends DAOFactory{

	@Override
	public TVADAO getTVADAO() {
		
		return MySQLTVADAO.getInstance();
	}

	@Override
	public ClientDAO getClientDAO() {
		return MySQLClientDAO.getInstance();
	}

	@Override
	public ProduitDAO getProduitDAO() {
		return MySQLProduitDAO.getInstance();
	}

	@Override
	public FactureDAO getFactureDAO() {
		return MySQLFactureDAO.getInstance();
	}

	@Override
	public Ligne_factureDAO getlignefactureDAO() {
		return MySQLLignefactureDAO.getInstance();
	}

}
