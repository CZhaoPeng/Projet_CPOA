package MySQL;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import dao.DAOFactory;
import dao.FactureDAO;
import dao.DAOFactory.Persistance;
import metier.Connexion;
import metier.Facture;

public class MySQLFactureDAO implements FactureDAO{
	DateTimeFormatter formatage = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	private static MySQLFactureDAO instance;
	public MySQLFactureDAO(){
		
	}
	public static MySQLFactureDAO getInstance(){
		if(instance == null)
		{
			instance = new MySQLFactureDAO();
		}
		return instance;
	}
	public Facture getById(int id) {

		try (
				PreparedStatement requete = Connexion.getInstance().creeConnexion().prepareStatement("select * from facture where id_facture = ?");
				)
		{
			
			requete.setInt(1, id);
			ResultSet res = requete.executeQuery();
			
			while(res.next()) {
				Facture f = new Facture();
				f.setId(res.getInt(1));
				f.setIdclient(DAOFactory.getDAOFactory(Persistance.MYSQL).getClientDAO().getById(res.getInt(2)));
				f.setDate(res.getDate(3).toLocalDate());
				return f;
			}

		}
		catch(SQLException sqle) {
			System.out.println("Pb select ID "+sqle.getMessage());
		}
		
		return null;
	}

	@Override
	public void create(Facture objet) {
	try (
			Connection laConnexion = Connexion.getInstance().creeConnexion();
			PreparedStatement requete = laConnexion.prepareStatement("insert into facture (id_client,date_facture) values(?,?)",Statement.RETURN_GENERATED_KEYS);	

			)
	{ 
		requete.setInt(1, objet.getIdclient().getId());
		requete.setDate(2, Date.valueOf(objet.getDate()));
		 requete.executeUpdate();
		 ResultSet res = requete.getGeneratedKeys();
		 if (res.next())
				objet.setId(res.getInt(1));
		}
		catch(SQLException sqle) {
			System.out.println("Pb create"+sqle.getMessage());
		}
		
	}

	@Override
	public void update(Facture objet) {
			try (
					
					Connection laConnexion = Connexion.getInstance().creeConnexion();
					PreparedStatement requete = laConnexion.prepareStatement("update facture set id_client=?, date_facture=? where id_facture=?");	

					)
			{						
				requete.setInt(1,objet.getIdclient().getId());
				requete.setDate(2,Date.valueOf(objet.getDate()));
				requete.setInt(3, objet.getId());
				requete.executeUpdate();
			}
			catch(SQLException sqle) {
				System.out.println("Pb update "+sqle.getMessage());
			}
	}

	@Override
	public void delete(Facture objet) {
		
	try (
			Connection laConnexion = Connexion.getInstance().creeConnexion();
			PreparedStatement requete = laConnexion.prepareStatement("delete from facture where id_facture = ?");

			)
	{
		
		requete.setInt(1,objet.getId());
		requete.executeUpdate();
			
	}
	catch(SQLException sqle) {
		System.out.println("Pb select"+sqle.getMessage());
	}
	}
	
		
	@Override
	public ArrayList<Facture> findAll(){
		ArrayList<Facture> listefacture = new ArrayList<>();
		try(
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("select * from facture");
				ResultSet res = requete.executeQuery();
				)
		{
			while(res.next())
				listefacture.add(new Facture(res.getInt(1),DAOFactory.getDAOFactory(Persistance.MYSQL).getClientDAO().getById(res.getInt(2)),res.getDate(3).toLocalDate()));
		}catch(SQLException sqle) 
		{
			System.out.println("Pb facturefindAll "+sqle.getMessage());
		}
		return listefacture;
	}
}

