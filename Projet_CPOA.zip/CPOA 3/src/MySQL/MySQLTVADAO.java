package MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dao.TVADAO;
import metier.Connexion;
import metier.TVA;

public class MySQLTVADAO implements TVADAO{
	private static MySQLTVADAO instance;
	public MySQLTVADAO(){
		
	}
	public static MySQLTVADAO getInstance(){
		if(instance == null)
		{
			instance = new MySQLTVADAO();
		}
		return instance;
	}
	@Override
	public TVA getById(int id) {
		
		try
		(
			PreparedStatement requete = Connexion.getInstance().creeConnexion().prepareStatement("SELECT * FROM tva WHERE id_tva =?");		
		)
		{
			requete.setInt(1, id);
			ResultSet res = requete.executeQuery();
			if(res.next()) {
				TVA tva = new TVA();
				tva.setId(res.getInt(1));
				tva.setLibelle(res.getString("libelle_tva"));
				tva.setTaux(res.getFloat("taux_tva"));
				return tva;
			} 
		}
		catch (SQLException | NullPointerException sqle) {
			 System.out.println("Problème select " + sqle.getMessage());
		}
		return null;
	}

	@Override
	public void create(TVA objet) {
		try(
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("insert into tva (libelle_tva,taux_tva) values(?,?)",Statement.RETURN_GENERATED_KEYS);
			)
		{ 	
			
			requete.setString(1, objet.getLibelle());
			requete.setFloat(2, objet.getTaux());
			requete.executeUpdate();
			ResultSet res = requete.getGeneratedKeys();
			if (res.next())
				objet.setId(res.getInt(1));
		}
		catch(SQLException sqle) {
			System.out.println("Pb create"+sqle.getMessage());
		}
		
	}

	@Override
	public void update(TVA objet) {
		try (
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("update tva set libelle_tva=?,taux_tva=? where id_tva=?");
				)
		{
			requete.setInt(3, objet.getId());
			requete.setString(1, objet.getLibelle());
			requete.setFloat(2, objet.getTaux());
			requete.executeUpdate();
		}
		catch(SQLException sqle) {
			System.out.println("Pb update"+sqle.getMessage());
		}
	}

	@Override
	public void delete(TVA objet) {
		try (
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("delete from tva where id_tva = ?");
				)
		{
			
			requete.setInt(1,objet.getId());
			requete.executeUpdate();
				
		}
		catch(SQLException sqle) {
			System.out.println("Pb delete"+sqle.getMessage());
		}
		
	}
	@Override
	public ArrayList<TVA> findAll() {
		ArrayList<TVA> listetva = new ArrayList<>();
		try (
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("select * from tva");
				ResultSet res = requete.executeQuery();
			)
		{	
			
				while(res.next())
					listetva.add(new TVA(res.getInt(1),res.getString("libelle_tva"),res.getFloat("taux_tva")));
		}catch(SQLException sqle) {
			System.out.println("Pba tvafindAll "+sqle.getMessage());
		}			
		return listetva;
	}
	
}
