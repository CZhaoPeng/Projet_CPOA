package MySQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dao.DAOFactory;
import dao.Ligne_factureDAO;
import dao.DAOFactory.Persistance;
import metier.Connexion;
import metier.Ligne_facture;

public class MySQLLignefactureDAO implements Ligne_factureDAO{
	private static MySQLLignefactureDAO instance;
	public MySQLLignefactureDAO(){
		
	}
	public static MySQLLignefactureDAO getInstance(){
		if(instance == null)
		{
			instance = new MySQLLignefactureDAO();
		}
		return instance;
	}
	@Override
	public Ligne_facture getById(int id) {	
		try(
				PreparedStatement requete = Connexion.getInstance().creeConnexion().prepareStatement("select * from ligne_facture where id_facture=?");	
				) 
		{
			requete.setInt(1, id);
			ResultSet res = requete.executeQuery();
				
				
				if(res.next()) {
	
					{
					Ligne_facture lf = new Ligne_facture();
					lf.setId(res.getInt(1));
					lf.setIdligne(res.getInt(2));
					lf.setIdproduit(MySQLProduitDAO.getInstance().getById(res.getInt(3)));
					lf.setQuantite(res.getInt(4));
					return lf;
					}		
				}
			
			}
			catch(SQLException sqle) {
				System.out.println("Pb select"+sqle.getMessage());
			}
			
			return null;
	}

	@Override
	public void create(Ligne_facture objet) {
		
		try(
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("insert ligne_facture (id_ligne,id_produit,quantite) values(?,?,?)",Statement.RETURN_GENERATED_KEYS);
			)
		{ 
			requete.setInt(1, objet.getIdligne());
			requete.setInt(2, objet.getIdproduit().getId());
			requete.setInt(3, objet.getQuantite());
			 requete.executeUpdate();
			 ResultSet res = requete.getGeneratedKeys();
			 if (res.next())
					objet.setId(res.getInt(1));
		}
		catch(SQLException sqle) {
			System.out.println("Pb create"+sqle.getMessage());
		}
	}

	@Override
	public  void update(Ligne_facture objet) {
			try (
					Connection laConnexion = Connexion.getInstance().creeConnexion();
					PreparedStatement requete = laConnexion.prepareStatement("update ligne_facture set id_ligne=?,id_produit=?,quantite=? where id_facture=?");
																
				)
			{
				
				requete.setInt(1,objet.getIdligne());
				requete.setInt(2,objet.getIdproduit().getId() );
				requete.setInt(3,objet.getQuantite());
				requete.setInt(4,objet.getId());
				requete.executeUpdate();
			}
			catch(SQLException sqle) {
				System.out.println("Pb update "+sqle.getMessage());
			}
	}

	@Override
	public void delete(Ligne_facture objet) {
		
	try (
			Connection laConnexion = Connexion.getInstance().creeConnexion();
			PreparedStatement requete = laConnexion.prepareStatement("delete from ligne_facture where id_facture = ?");
		)
	{
		
		requete.setInt(1, objet.getId());
		requete.executeUpdate();
			
	}
	catch(SQLException sqle) {
		System.out.println("Pb delete"+sqle.getMessage());
	}
	}
	
	@Override
	public ArrayList<Ligne_facture> findAll() {
		ArrayList<Ligne_facture> listelignefacture = new ArrayList<>();
		try(
				Connection laConnexion = Connexion.getInstance().creeConnexion();
				PreparedStatement requete = laConnexion.prepareStatement("select * from ligne_facture");
				ResultSet res = requete.executeQuery();	
			)
		{
			while(res.next())
				listelignefacture.add(new Ligne_facture(res.getInt(1), res.getInt(2), DAOFactory.getDAOFactory(Persistance.MYSQL).getProduitDAO().getById(res.getInt(3)),res.getInt(4)));
		}catch(SQLException sqle) {
			System.out.println("Pb lffindAll"+sqle.getMessage());
		}
		return listelignefacture;
	}
}
